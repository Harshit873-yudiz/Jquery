$(document).ready(function(){
    
    $("#h1").click(function(){
        $("p").hide(1000); 
        $("#p1").show(1000); 
    }); 
    
    $("#h2").click(function(){
      $("p").hide(1000); 
      $("#p2").show(1000);
    });

    $("#h3").click(function(){
      $("p").hide(1000); 
      $("#p3").show(1000);
    }); 
    
     $("p").hide(); 
});

