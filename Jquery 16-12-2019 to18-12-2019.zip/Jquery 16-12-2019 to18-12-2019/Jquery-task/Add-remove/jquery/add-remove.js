$(document).ready( function(){
    $('#button').click(function(){
        var toAdd = $('[name=ListItem]').val();
         $('ul').append('<li>' +toAdd+"<i class='fa'>&#xf00d;</i>"+'</li>');
    });
      
    $(document).on('click','li', function(){
      $(this).remove();    
    });
});