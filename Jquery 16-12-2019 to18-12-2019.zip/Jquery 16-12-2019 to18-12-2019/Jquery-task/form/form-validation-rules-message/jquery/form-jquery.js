$("document").ready(function() {
  $("form[name='registration']").validate({
   
    rules: {
      firstname:{
        required:true,
        minlength:3,
        maxlength:12,
        regex:"[^0-9]$"
      },
      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5,
        maxlength:12
      }
    },
    messages: {
      firstname:{
        required:"Enter firstname",
        minlength:"minlength3",
        maxlength:"maxlength12",
        regex:"do not insert number"
      },
      email:{
        required:"Enter Email id",
        email: "Please enter a valid email address"
      },
      password: {
        required: "Please provide a password",
        minlength: "minlength 5",
        maxlength:"maxlength12"
      }
    },
    submitHandler: function(form) {
      form.submit();
    }
  });
});
$.validator.addMethod(
      "regex",
      function(value, element, regexp) {
          var check = false;
          var re = new RegExp(regexp);
          return this.optional(element) || re.test(value);
      },""
);