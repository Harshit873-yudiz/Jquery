$("document").ready(function(){

	$("input").keyup(function(){
		var name=$(this).val();
		console.log(name);
		if(name.toString().length<3 || name.toString().length>12){
			$(this).parents('.form-group').find(".alert").html("input valu should be min 3 max 12 char");
		}
		else{
			$(this).parents('.form-group').find(".alert").html("");	
		}
	});

	$("form").submit(function(e) {
	e.preventDefault();
		//user Name:
		var name=$('#name').val();
		if(name.toString().length<3 || name.toString().length>12){
			$(".alert").html("input valu be min 3 max 12 char");
		}
		else{
			$('.alert').html("");	
		}
		//password
		var password=$("#pwd").val();
		if(password.length<3||password.length>12){
			$(".alert").html(" input value should be min 3 max 12 char");
		}
		else{
			$(".alert").html("");
		}
		
		$("form")[0].reset();
	});
	//return true;
});

		

