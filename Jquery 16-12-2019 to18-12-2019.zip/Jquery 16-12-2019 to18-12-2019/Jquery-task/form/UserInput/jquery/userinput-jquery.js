$("document").ready(function(){

	//user form
	$("form").submit(function(e) {
	e.preventDefault();
		var name = $('#name').val();
		var pwd = $("#pwd").val();
		var email = $("#email").val();
		$("form")[0].reset();
		$('#results').html("User Name:"+name +"<br>"+"Pasword:"+pwd+"<br>"+"Email:"+email);
	});

	// calculator
	//Add
	$("[id = Add]").click(function(){
		var val1=parseInt($('#val1').val());
		var val2=parseInt($('#val2').val());
		var add=val1+val2;
		$("#Ans").html("Add is :"+add);
	});

	//sub
	$("[id = Sub]").click(function(){
		var val1=parseInt($('#val1').val());
		var val2=parseInt($('#val2').val());
		var sub=val1-val2;
		$("#Ans").html("Sub is :"+sub);
	});

	//multi
	$("[id = Multi]").click(function(){
		var val1=parseInt($('#val1').val());
		var val2=parseInt($('#val2').val());
		var multi=val1*val2;
		$("#Ans").html("multi is :"+multi);
	});

	//div
	$("[id = Div]").click(function(){
		var val1=parseInt($('#val1').val());
		var val2=parseInt($('#val2').val());
		var div=val1/val2;
		$("#Ans").html("div is :"+div);
	});

	//User text print
    $("#utext").keyup(function(){
        var arr = $(this).val();
        $("#insertedvalue").text(arr);
    });

    //browser click count
    var userclick=0;
	$(document).click(function(){
		userclick++;
		$("#user-click").val(userclick);
	});

});	
