//global variable
var oldColor1,oldColor2,oldColor3,oldColor4;

$(document).ready(function(){
    $("#sc1").click(function(){
      $("#div1").toggleClass("div1");
    });

    $("#sc2").click(function(){
      $("#div2").toggleClass("div2");
    });

    $("#sc3").click(function(){
      $("#div3").toggleClass("div3");
    });

    $("#sc4").click(function(){
      $("#div4").toggleClass("div4");
    });   
});

