$(document).ready(function(){
	$("h1").click(function(){alert("hello");});
	$("#demo").css("background-color","yellow");
	$("ul li:first").css("background-color","yellow");
	$(".liclass").css("background-color","blue");
	$("li:not(.liclass)").css("font-size","22px");
	$("strong+em").css("background-color","yellow");
	$("div[p]").css("color","blue");
	
	$("#hide").click(function(){
		$("img").hide(1000);
	});
	$("#show").click(function(){
		$("img").show(1000);
	});
	var title=$("em").attr("title");
	$("#divid").text(title); 
	//$("#myimg").attr("src","images/shinchan2.jpg");
	$("#demo2").addClass("heighlight");
	$("table").removeAttr("border");
	$("p").find("span").css("color","red");
	$("li").filter(function(index){
		return index==1||$(this).attr("class")=="mid";
	}).addClass("heighlight");

	 $("li").click(function () {
				
               if ($(this).is(":first-child")) {
                  $("#FILLER").text("This is list item 1");
               } else if ($(this).is(".middle0,.middle1")) {
                  $("#FILLER").text("This is middle class list");
               } else if ($(this).is(":contains('item 5')")) {
                  $("#FILLER").text("It's 5th list");
               } 
            });
	 $("#mydiv1").css('background-color','green','font-size','28px');
	 $("#division").click(function(){
	 	var content=$(this).html();
	 	$("#result").text(content);
	 });
	 $("#division1").click(function(){
	 	$(this).replaceWith("Hello World!!");
	 });
	 $("a").click(function(){
	 	event.preventDefault();
	 	alert("Default browser is desabled");
	 });	

	 $("#old").click(function(){
	 	$("#TEXT").trigger("focus");
	 });

	 $("#new").click(function(){
	 	$("#TEXT").triggerHandler("focus");
	 });

	 $("#TEXT").focus(function(){
	 	$("<span>focused!</span>").appendTo("#Focus").fadeOut(1000);
	 });

	 $("#out").click(function(){
	 	$("#block").animate({width:"70%",opacity:0.4,fontSize:"3em"},1500);
	 });
	 $("#in").click(function(){
	 	$("#block").animate({width:"100",opacity:1.0,fontSize:"100%"},1500);
	 })
});